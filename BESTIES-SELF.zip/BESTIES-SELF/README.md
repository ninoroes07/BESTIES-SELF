<p align="center">
<img src="https://g.top4top.io/p_1888lawbj1.png" alt="png" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="SELF BOT" src="https://img.shields.io/badge/SELF BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/MrG3P5"><img title="Author" src="https://img.shields.io/badge/Author-X MrG3P5-red.svg?style=for-the-badge&logo=github"></a>
</p>

## APIKEY & Author Packname sticker
Buka file config.json dan paste apikey di YOUR_APIKEY
- [VHTEAR](https://api.vhtear.com)
- [Youtube-APIV3](https://www.youtube.com/watch?v=TE66McLMMEw)

### Installasi In TERMUX

```bash
> apt update && apt upgrade -y
> pkg install git -y
> pkg install bash -y
> git clone https://github.com/ninoroes07/BESTIES-SELF.git
> cd SELF-BOT
> bash install.sh
> npm start
```

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker WM                        |
|       ✅       | Sticker Trigger                   |
|       ✅       | sticker wasted                   |

| Group |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  hidetag               |
|       ✅        |  grup close atau open       |
|       ✅        |  gcname          |
|       ✅        |  gcdesk       |
|       ✅        |  add              |
|       ✅        |  kick              |
|       ✅        |  tagall              |
|       ✅        |  ownergc              |
|       ✅        |  leave              |
|       ✅        |  promote              |
|       ✅        |  demote              |

| MEDIA |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  ytstalk              |
|       ✅        |  tomp3              |
|       ✅        |  brainly              |
|       ✅        |  truth              |
|       ✅        |  dare              |
|       ✅        |  play              |
|       ✅        |  pinterest              |
|       ✅        |  tahta              |
|       ✅        |  ssweb              |
|       ✅        |  igstalk              |
|       ✅        |  playstore              |
|       ✅        |  infoalamat              |
|       ✅        |  puisiimg              |
|       ✅        |  tiktok              |
|       ✅        |  toimg              |

| STORAGE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  addsticker             |
|       ✅        |  getsticker             |
|       ✅        |  delsticker             |
|       ✅        |  stickerlist             |
|       ✅        |  addvn             |
|       ✅        |  getvn             |
|       ✅        |  delvn             |
|       ✅        |  listvn             |
|       ✅        |  addvideo             |
|       ✅        |  getvideo             |
|       ✅        |  delvideo             |
|       ✅        |  listvideo             |
|       ✅        |  addimage             |
|       ✅        |  getimage             |
|       ✅        |  delimage             |
|       ✅        |  listimage             |

| ADVANCE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  upstatus             |
|       ✅        |  setpp             |
|       ✅        |  clearall             |
|       ✅        |  readallchat             |
|       ✅        |  fakedeface             |
|       ✅        |  setthumb             |
|       ✅        |  antidelete group             |
|       ✅        |  antidelete kontak             |
|       ✅        |  return             |
|       ✅        |  cr1 (fake reply grup)             |
|       ✅        |  cr2 (fake reply private)             |
|       ✅        |  runtime             |
|       ✅        |  settarget             |
|       ✅        |  term             |
|       ✅        |  ping             |
|       ✅        |  setreply             |
|       ✅        |  setnumber             |
|       ✅        |  info             |
|       ✅        |  cekchat             |

| VOICE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  slowmo             |
|       ✅        |  bass             |
|       ✅        |  tupai             |
|       ✅        |  toptt             |

| PENTEST |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  findhost             |
|       ✅        |  dork             |
|       ✅        |  nmap             |


## 🙏Special Thanks To
<ul>
<li>https://github.com/adiwajshing/Baileys<br>
<li>https://github.com/MhankBarBar<br>
</li>
